package org.example;

import com.auth0.jwk.Jwk;
import com.auth0.jwk.JwkProvider;
import com.auth0.jwk.JwkProviderBuilder;
import com.auth0.jwk.UrlJwkProvider;
import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.JWTVerifier;

import java.net.URL;
import java.security.interfaces.RSAPublicKey;

public class AzureADTokenValidator {

    private static final String ISSUER = "https://sts.windows.net/34fa0c9a-e131-4a4c-80b1-d058a1f5e46c/";
    private static final String AUDIENCE = "api://2bc860cb-f797-43a2-9ca5-dbe009643e2a";
    private static final String JWKS_URI = "https://login.microsoftonline.com/34fa0c9a-e131-4a4c-80b1-d058a1f5e46c/discovery/v2.0/keys";

    private final JwkProvider jwkProvider;

    public AzureADTokenValidator() throws Exception {
        // Bypass cache by using UrlJwkProvider
        System.out.println("Fetching JWKs directly without caching...");
        jwkProvider = new UrlJwkProvider(new URL(JWKS_URI));
        //jwkProvider = new JwkProviderBuilder(JWKS_URI).build();
    }

    public boolean validateToken(String token) throws Exception {
        DecodedJWT decodedJWT = null;
        // Decode the JWT without verifying the signature yet
        try {
            decodedJWT = JWT.decode(token);
        }
        catch (Exception ee){
            System.out.println(ee.getMessage());
            return false;
        }
        // Log the Audience and Issuer
        System.out.println("Audience: " + decodedJWT.getAudience());
        System.out.println("Issuer: " + decodedJWT.getIssuer());

        // Validate the issuer
        if (!decodedJWT.getIssuer().equals(ISSUER)) {
            throw new Exception("Invalid issuer");
        }

        // Validate the audience
        if (!decodedJWT.getAudience().contains(AUDIENCE)) {
            throw new Exception("Invalid audience");
        }

        try {
            // Log the key ID for clarity
            System.out.println("Fetching the public key for key ID: " + decodedJWT.getKeyId());

            // Get the JWK (public key) based on the "kid" from the JWT header, bypassing cache
            Jwk jwk = jwkProvider.get(decodedJWT.getKeyId());
            RSAPublicKey publicKey = (RSAPublicKey) jwk.getPublicKey();

            // Validate the token's signature using the public key
            Algorithm algorithm = Algorithm.RSA256(publicKey, null);
            JWTVerifier verifier = JWT.require(algorithm)
                    .withIssuer(ISSUER)
                    .withAudience(AUDIENCE)
                    .build();
            verifier.verify(token);  // This will throw an exception if the token is invalid

        } catch (Exception e) {
            System.err.println("Error fetching the JWK for key ID: " + decodedJWT.getKeyId());
            e.printStackTrace();
            throw e;
        }

        // If all validations pass, return true
        return true;
    }
}
