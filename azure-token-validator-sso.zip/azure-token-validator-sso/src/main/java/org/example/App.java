package org.example;

/**
 * Hello world!
 */
public class App {
    public static void main(String[] args) throws Exception{

        System.out.println("Hello World!");
        try {
            AzureADTokenValidator tokenValidator = new AzureADTokenValidator();
            String accessToken = "ey0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6Ikg5bmo1QU9Tc3dNcGhnMVNGeDdqYVYtbEI5dyIsImtpZCI6Ikg5bmo1QU9Tc3dNcGhnMVNGeDdqYVYtbEI5dyJ9.eyJhdWQiOiJhcGk6Ly8yYmM4NjBjYi1mNzk3LTQzYTItOWNhNS1kYmUwMDk2NDNlMmEiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC8zNGZhMGM5YS1lMTMxLTRhNGMtODBiMS1kMDU4YTFmNWU0NmMvIiwiaWF0IjoxNzI1ODA3NTg3LCJuYmYiOjE3MjU4MDc1ODcsImV4cCI6MTcyNTgxMTQ4NywiYWlvIjoiRTJkZ1lKRFNsVnZ3ZDhtUnlVdmZHbWZQTS9SM0JRQT0iLCJhcHBpZCI6IjJiYzg2MGNiLWY3OTctNDNhMi05Y2E1LWRiZTAwOTY0M2UyYSIsImFwcGlkYWNyIjoiMSIsImlkcCI6Imh0dHBzOi8vc3RzLndpbmRvd3MubmV0LzM0ZmEwYzlhLWUxMzEtNGE0Yy04MGIxLWQwNThhMWY1ZTQ2Yy8iLCJvaWQiOiI2ZTY4NjlmMS0xMzUxLTQzMDktOWNjMy0yYTAwMjE3MzMzMmEiLCJyaCI6IjAuQWNZQW1nejZOREhoVEVxQXNkQllvZlhrYk10Z3lDdVg5NkpEbktYYjRBbGtQaXJHQUFBLiIsInN1YiI6IjZlNjg2OWYxLTEzNTEtNDMwOS05Y2MzLTJhMDAyMTczMzMyYSIsInRpZCI6IjM0ZmEwYzlhLWUxMzEtNGE0Yy04MGIxLWQwNThhMWY1ZTQ2YyIsInV0aSI6IlNyOWRwbVMzUFV1S2dVNG1CbEMzQUEiLCJ2ZXIiOiIxLjAifQ.PPU8zEr5OAl4EFLkYudbgKbX0MoFB9p9tjbMzDIv-91qYx4sGJ8QwHgTuHGIMQuH47SRwL3slyV1gVCVG0YoyjUVuYAVIBvxQ-mMVccSg43-a88x47jqsbXTgU-1hRRe3mvCozO9ZtSaOy9EqQQy1ZaUtPzXBczblzIpmBo--4OiyIghWuIuyjr5-ponJO6sakqMeVHn7j9M5l26lPc1CcOxWk-FROSHbqtmjkBKnc0YDWVJ-vo0MeASrTA7R2R4kr9hXn8Ho1vggBgbIg4t0IV7-MVdeTm4CLGNok3xj5tGpheRvHv40IM4r1eBmlTOWCxjBRaH7povFrpmLpo4Yg";
            boolean flag = tokenValidator.validateToken(accessToken);
            if (flag) System.out.println("Excellent, its an valid token");
            else System.out.println("Sorry its invalid token");

        } catch (Exception ee) {
            System.out.println(ee.getMessage());
        }
    }
}
